#!/usr/bin/env bash
# install.sh — one-command installer for foto
# Run with:  bash install.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FOTO_PY="$SCRIPT_DIR/foto.py"
INSTALL_DIR="$HOME/.local/bin"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  🎨  foto installer                           ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 1. Check Python ──────────────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "❌  python3 not found."
    echo "    Install it with your package manager, e.g.:"
    echo "      Ubuntu/Debian:  sudo apt install python3"
    echo "      Fedora:         sudo dnf install python3"
    echo "      Arch:           sudo pacman -S python"
    exit 1
fi

PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "  ✅  Python $PY_VERSION found"

# ── 2. Make foto.py executable ───────────────────────────────────────────────
chmod +x "$FOTO_PY"
echo "  ✅  Made foto.py executable"

# ── 3. Create ~/.local/bin if missing ───────────────────────────────────────
mkdir -p "$INSTALL_DIR"

# ── 4. Install the launcher ──────────────────────────────────────────────────
LAUNCHER="$INSTALL_DIR/foto"
cat > "$LAUNCHER" <<EOF
#!/usr/bin/env bash
exec python3 "$FOTO_PY" "\$@"
EOF
chmod +x "$LAUNCHER"
echo "  ✅  Installed launcher → $LAUNCHER"

# ── 5. Make sure ~/.local/bin is on PATH ─────────────────────────────────────
SHELL_RC=""
case "${SHELL:-}" in
    */zsh)  SHELL_RC="$HOME/.zshrc" ;;
    */fish) SHELL_RC="$HOME/.config/fish/config.fish" ;;
    *)      SHELL_RC="$HOME/.bashrc" ;;
esac

PATH_LINE='export PATH="$HOME/.local/bin:$PATH"'
if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    echo "" >> "$SHELL_RC"
    echo "# Added by foto installer" >> "$SHELL_RC"
    echo "$PATH_LINE" >> "$SHELL_RC"
    echo "  ✅  Added $INSTALL_DIR to PATH in $SHELL_RC"
    export PATH="$INSTALL_DIR:$PATH"
else
    echo "  ✅  $INSTALL_DIR already on PATH"
fi

# ── 6. Pre-install Python deps so first run is instant ───────────────────────
echo ""
echo "  📦  Pre-installing Python packages (Pillow, termimage) …"
python3 -m pip install --quiet Pillow termimage 2>/dev/null && \
    echo "  ✅  Packages ready" || \
    echo "  ⚠️  Package install had warnings — foto will retry on first run."

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  🎉  All done!  You can now run:              ║"
echo "║                                               ║"
echo "║      foto                    ← opens picker   ║"
echo "║      foto mycat.jpg          ← direct path    ║"
echo "║      foto --help             ← see all flags  ║"
echo "║                                               ║"
echo "║  (Open a new terminal if 'foto' isn't found)  ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
