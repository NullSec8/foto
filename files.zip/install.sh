#!/usr/bin/env bash
# install.sh — one-command installer for foto
# Run:  bash install.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FOTO_PY="$SCRIPT_DIR/foto.py"
BIN_DIR="$HOME/.local/bin"

echo ""
echo "╔═══════════════════════════════════════════╗"
echo "║  🎨  foto installer                        ║"
echo "╚═══════════════════════════════════════════╝"
echo ""

# ── Python ───────────────────────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "❌  python3 not found. Install it first:"
    echo "    Ubuntu/Debian:  sudo apt install python3"
    echo "    Fedora:         sudo dnf install python3"
    echo "    Arch:           sudo pacman -S python"
    exit 1
fi
PY=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "  ✅  Python $PY"

# ── Python packages ───────────────────────────────────────────────────────────
echo "  📦  Installing Pillow and termimage …"
python3 -m pip install --quiet Pillow termimage 2>/dev/null \
    && echo "  ✅  Pillow + termimage" \
    || echo "  ⚠️   pip had issues — foto will retry on first run"

# ── Optional: tkinter for GUI file picker ────────────────────────────────────
if ! python3 -c "import tkinter" 2>/dev/null; then
    echo ""
    echo "  ℹ️   python3-tk is not installed."
    echo "      Without it, foto will use a terminal prompt (Tab-completion works!)."
    echo "      To enable the GUI file picker, run:"
    if command -v apt &>/dev/null; then
        echo "        sudo apt install python3-tk"
    elif command -v dnf &>/dev/null; then
        echo "        sudo dnf install python3-tkinter"
    elif command -v pacman &>/dev/null; then
        echo "        sudo pacman -S tk"
    else
        echo "        (install the tkinter package for your distro)"
    fi
    echo ""
fi

# ── Launcher ─────────────────────────────────────────────────────────────────
chmod +x "$FOTO_PY"
mkdir -p "$BIN_DIR"

LAUNCHER="$BIN_DIR/foto"
cat > "$LAUNCHER" <<EOF
#!/usr/bin/env bash
exec python3 "$FOTO_PY" "\$@"
EOF
chmod +x "$LAUNCHER"
echo "  ✅  Installed: $LAUNCHER"

# ── PATH ─────────────────────────────────────────────────────────────────────
SHELL_RC=""
case "${SHELL:-}" in
    */zsh)  SHELL_RC="$HOME/.zshrc" ;;
    */fish) SHELL_RC="$HOME/.config/fish/config.fish" ;;
    *)      SHELL_RC="$HOME/.bashrc" ;;
esac

PATH_LINE='export PATH="$HOME/.local/bin:$PATH"'
if [[ ":${PATH}:" != *":${BIN_DIR}:"* ]]; then
    { echo ""; echo "# Added by foto installer"; echo "$PATH_LINE"; } >> "$SHELL_RC"
    export PATH="$BIN_DIR:$PATH"
    echo "  ✅  Added $BIN_DIR to PATH in $SHELL_RC"
else
    echo "  ✅  $BIN_DIR already on PATH"
fi

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo "╔═══════════════════════════════════════════╗"
echo "║  🎉  Done! Open a new terminal, then run:  ║"
echo "║                                            ║"
echo "║    foto              ← type/drag a file    ║"
echo "║    foto mycat.jpg    ← direct path         ║"
echo "║    foto --help       ← all options         ║"
echo "╚═══════════════════════════════════════════╝"
echo ""
