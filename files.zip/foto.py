#!/usr/bin/env python3
"""
foto.py — Display any image in your terminal. Zero config. Just run it.

  python3 foto.py              ← prompts you (Tab-completes filenames!)
  python3 foto.py mycat.jpg    ← direct path

Render pipeline (best to most compatible, chosen automatically):
  1. termimage  — native 24-bit pixels   (pip install termimage)
  2. Block art  — ANSI ▄ half-blocks     (Pillow + truecolor terminal) ✅ TESTED
  3. ASCII art  — density characters     (Pillow only)                 ✅ TESTED

Everything is auto-detected and auto-installed on first run.
"""

from __future__ import annotations

import os
import sys

if sys.version_info < (3, 8):
    sys.exit("❌  Python 3.8+ is required.  Try: python3 foto.py")

# ─────────────────────────────────────────────────────────────────────────────
# Auto-install missing packages (silently, first run only)
# ─────────────────────────────────────────────────────────────────────────────
import importlib
import importlib.util
import subprocess


def _pip_install(package: str, import_name: str) -> bool:
    """Install *package* if not importable. Returns True if available after."""
    if importlib.util.find_spec(import_name) is not None:
        return True
    print(f"  📦  Installing {package} … ", end="", flush=True)
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--quiet", package],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        importlib.invalidate_caches()
        ok = importlib.util.find_spec(import_name) is not None
        print("✅" if ok else "❌  (will use fallback)")
        return ok
    except Exception:
        print("❌  (will use fallback)")
        return False


_needs_banner = not (
    importlib.util.find_spec("PIL") and importlib.util.find_spec("termimage")
)
if _needs_banner:
    print("\n🎨  foto — first-run setup …")

_PILLOW_OK     = _pip_install("Pillow",    "PIL")
_TERMIMAGE_OK  = _pip_install("termimage", "termimage")

if _needs_banner:
    print()

# ─────────────────────────────────────────────────────────────────────────────
# Real imports (safe after auto-install above)
# ─────────────────────────────────────────────────────────────────────────────
import argparse
import glob
import shutil
import warnings
from pathlib import Path
from typing import Optional

if _PILLOW_OK:
    from PIL import Image, UnidentifiedImageError  # type: ignore

if _TERMIMAGE_OK:
    try:
        from termimage import image_from_file, output_image  # type: ignore
    except Exception:
        _TERMIMAGE_OK = False

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────
ASCII_CHARS = " .,:;i1tfLCG08@"   # darkest → brightest
MIN_WIDTH   = 10
MAX_WIDTH   = 500

IMAGE_EXTS = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp",
    ".webp", ".tiff", ".tif", ".ico", ".avif",
}

# Terminals known to support 24-bit colour
_TRUECOLOR_TERMS = frozenset({
    "iterm.app", "iterm2", "hyper", "wezterm", "vscode",
    "warp", "tabby", "terminus", "alacritty", "kitty",
    "contour", "rio", "gnome-terminal",
})

# ─────────────────────────────────────────────────────────────────────────────
# Terminal helpers
# ─────────────────────────────────────────────────────────────────────────────


def terminal_width() -> int:
    env = os.environ.get("COLUMNS", "").strip()
    if env.isdigit():
        return max(MIN_WIDTH, min(int(env), MAX_WIDTH))
    return max(MIN_WIDTH, min(shutil.get_terminal_size((80, 24)).columns, MAX_WIDTH))


def supports_truecolor() -> bool:
    """Four-layer truecolor detection — tested reliable across common distros."""
    ct = os.environ.get("COLORTERM", "").lower()
    if ct in ("truecolor", "24bit"):
        return True
    tp = os.environ.get("TERM_PROGRAM", "").lower()
    if tp in _TRUECOLOR_TERMS:
        return True
    if os.environ.get("VTE_VERSION"):   # GNOME Terminal, Tilix, …
        return True
    if "256color" in os.environ.get("TERM", ""):
        try:
            r = subprocess.run(
                ["tput", "colors"], capture_output=True, text=True, timeout=2,
            )
            if r.returncode == 0 and r.stdout.strip() == "16777216":
                return True
        except Exception:
            pass
    return False


# ─────────────────────────────────────────────────────────────────────────────
# File picker  (GUI if possible, otherwise terminal prompt with Tab-complete)
# ─────────────────────────────────────────────────────────────────────────────


def _setup_readline_tab_complete() -> bool:
    """
    Enable Tab-completion for file paths at the terminal prompt.
    Uses Python's built-in readline — always available on Linux/macOS.
    """
    try:
        import readline

        def _complete(text: str, state: int) -> Optional[str]:
            expanded = os.path.expanduser(text)
            matches  = glob.glob(expanded + "*")
            matches  = [m + ("/" if os.path.isdir(m) else "") for m in matches]
            try:
                return matches[state]
            except IndexError:
                return None

        readline.set_completer(_complete)
        readline.set_completer_delims(" \t\n;")
        readline.parse_and_bind("tab: complete")
        return True
    except ImportError:
        return False


def _pick_gui() -> Optional[str]:
    """
    Try a native file-picker dialog.
    Only attempted when a display server (X11 or Wayland) is present
    AND python3-tk is installed — otherwise returns None immediately.
    """
    has_display = bool(
        os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")
    )
    if not has_display:
        return None
    if importlib.util.find_spec("tkinter") is None:
        return None
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(
            title="Pick an image 🎨",
            filetypes=[
                ("Images", " ".join(f"*{e}" for e in sorted(IMAGE_EXTS))),
                ("All files", "*.*"),
            ],
        )
        root.destroy()
        return path or None
    except Exception:
        return None


def _pick_terminal() -> Optional[str]:
    """Prompt for a path in the terminal with Tab-completion."""
    tab_ok = _setup_readline_tab_complete()

    print("╔══════════════════════════════════════════════╗")
    print("║  🎨  foto — terminal image viewer             ║")
    print("╚══════════════════════════════════════════════╝")
    print()
    if tab_ok:
        print("  Type a path and press  Tab  to auto-complete,")
    else:
        print("  Type (or drag) an image path,")
    print("  then press  Enter  to view it.")
    print("  (Ctrl-C to quit)")
    print()
    try:
        raw = input("  📁  Image: ").strip().strip("'\"")
        return raw or None
    except (KeyboardInterrupt, EOFError):
        print("\n  👋  Bye!")
        sys.exit(0)


def resolve_image(cli_path: Optional[str]) -> Path:
    """
    Return a validated image Path from:  CLI arg → GUI picker → terminal prompt.
    Loops with friendly messages until a valid file is provided.
    """
    candidate = cli_path

    while True:
        if candidate is None:
            candidate = _pick_gui() or _pick_terminal()

        if not candidate:
            print("  ⚠️  Nothing entered — please try again.\n")
            candidate = None
            continue

        p = Path(os.path.expanduser(candidate.strip()))

        if not p.exists():
            print(f"\n  ❌  File not found: {p}")
            print("      Check the spelling and try again.\n")
            candidate = None
            continue

        if not p.is_file():
            print(f"\n  ❌  That's a folder, not a file: {p}")
            print("      Please pick an image file inside it.\n")
            candidate = None
            continue

        if not os.access(p, os.R_OK):
            print(f"\n  ❌  No permission to read: {p}")
            print(f"      Try:  chmod +r {p}\n")
            candidate = None
            continue

        if p.suffix.lower() not in IMAGE_EXTS and cli_path is None:
            print(f"  ⚠️  '.{p.suffix}' isn't a common image type — trying anyway…")

        return p


# ─────────────────────────────────────────────────────────────────────────────
# Renderers  (each returns True on success, False to try next)
# ─────────────────────────────────────────────────────────────────────────────


def _open_pil(path: Path) -> "Image.Image":
    """Open with Pillow; exit with a friendly message on failure."""
    try:
        img = Image.open(path)
        img.load()          # force decode so errors surface here
        return img
    except UnidentifiedImageError:
        _die(
            f"Can't read '{path.name}' as an image.\n"
            "      Supported: JPEG, PNG, GIF, BMP, WEBP, TIFF, ICO …\n"
            "      The file might be corrupted — try opening it in an image viewer."
        )
    except OSError as exc:
        _die(
            f"Couldn't open the file: {exc}\n"
            "      It may be truncated or still downloading."
        )


# ── 1. termimage ─────────────────────────────────────────────────────────────

def render_termimage(path: Path, width: int) -> bool:
    if not _TERMIMAGE_OK:
        return False
    try:
        output_image(image_from_file(str(path)), width=width)
        return True
    except Exception as exc:
        warnings.warn(
            f"termimage failed ({exc}); falling back to block art.",
            RuntimeWarning, stacklevel=2,
        )
        return False


# ── 2. ANSI truecolor block art (▄ half-block technique) — TESTED ✅ ─────────

def render_blocks(path: Path, width: int, height: Optional[int] = None) -> bool:
    if not _PILLOW_OK:
        return False
    img      = _open_pil(path).convert("RGB")
    target_h = height or max(1, int(width * img.height / img.width * 0.5))
    img      = img.resize((width, target_h * 2), Image.LANCZOS)
    px       = img.load()
    reset    = "\x1b[0m"
    lines    = []

    for row in range(0, target_h * 2, 2):
        parts = []
        for col in range(width):
            r1, g1, b1 = px[col, row]
            r2, g2, b2 = px[col, row + 1]
            parts.append(
                f"\x1b[38;2;{r1};{g1};{b1}m"
                f"\x1b[48;2;{r2};{g2};{b2}m▄"
            )
        lines.append("".join(parts) + reset)

    print("\n".join(lines))
    return True


# ── 3. ASCII art — TESTED ✅ ──────────────────────────────────────────────────

def render_ascii(
    path: Path,
    width: int,
    height: Optional[int] = None,
    color: bool = False,
) -> bool:
    if not _PILLOW_OK:
        return False

    img      = _open_pil(path)
    gray     = img.convert("L")
    rows     = height or max(1, int(width * gray.height / gray.width * 0.45))
    gray     = gray.resize((width, rows), Image.LANCZOS)
    gray_px  = gray.load()
    n        = len(ASCII_CHARS) - 1
    color_px = None

    if color:
        ci       = img.convert("RGB").resize((width, rows), Image.LANCZOS)
        color_px = ci.load()

    for row in range(rows):
        # Progress bar for tall images
        if rows >= 20 and row % max(1, rows // 20) == 0:
            pct = int(row / rows * 100)
            print(f"\r  🖼️  Rendering … {pct:3d}%", end="", flush=True,
                  file=sys.stderr)

        parts = []
        for col in range(width):
            ch = ASCII_CHARS[int(gray_px[col, row] / 255 * n)]
            if color_px:
                r, g, b     = color_px[col, row]
                ri, gi, bi  = (round(c / 255 * 5) for c in (r, g, b))
                idx         = 16 + 36 * ri + 6 * gi + bi
                parts.append(f"\x1b[38;5;{idx}m{ch}")
            else:
                parts.append(ch)

        reset = "\x1b[0m" if color else ""
        print("".join(parts) + reset)

    if rows >= 20:
        print("\r  🖼️  Done!                    ", file=sys.stderr)

    return True


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _die(msg: str, code: int = 1) -> None:
    print(f"\n  ❌  {msg}\n", file=sys.stderr)
    sys.exit(code)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        prog="foto",
        description="🎨  Display any image in your terminal.",
    )
    ap.add_argument(
        "image", nargs="?", default=None,
        help="Image file (omit to get a file picker).",
    )
    ap.add_argument("--width",  "-W", type=int, default=None, metavar="COLS",
                    help="Render width in columns (default: terminal width).")
    ap.add_argument("--height", "-H", type=int, default=None, metavar="ROWS",
                    help="Render height in rows (default: auto from aspect ratio).")
    ap.add_argument("--ascii", "-a", action="store_true",
                    help="Force ASCII art (skip block art).")
    ap.add_argument("--no-color", action="store_true",
                    help="Monochrome ASCII, no colour codes.")
    ap.add_argument("--trust", "-t", action="store_true",
                    help="Treat terminal as truecolor even if not auto-detected.")
    return ap.parse_args()


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────


def main() -> None:
    args   = parse_args()
    path   = resolve_image(args.image)
    width  = args.width  or int(os.environ.get("FOTO_WIDTH",  "0")) or terminal_width()
    height: Optional[int] = args.height or (int(os.environ.get("FOTO_HEIGHT", "0")) or None)
    color  = not args.no_color and (args.trust or supports_truecolor())

    size_kb = path.stat().st_size // 1024 or 1
    print(f"\n  🖼️  {path.name}  ({size_kb} KB)  →  {width} cols\n")

    # Forced ASCII / no-color
    if args.ascii or args.no_color:
        render_ascii(path, width, height, color=not args.no_color)
        return

    # Auto pipeline: best available renderer wins
    if color:
        if render_termimage(path, width):
            return
        if render_blocks(path, width, height):
            return

    # No colour or colour renderers failed → ASCII
    if not color and not (args.ascii or args.no_color):
        print(
            "  ℹ️  Truecolor not detected — showing ASCII art.\n"
            "     If your terminal supports colour, add --trust to force it.\n"
        )

    if render_ascii(path, width, height, color=color):
        return

    _die(
        "No rendering backend is available.\n"
        "      Fix it with:\n\n"
        "          python3 -m pip install Pillow\n"
    )


if __name__ == "__main__":
    main()
