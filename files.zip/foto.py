#!/usr/bin/env python3
# foto.py — Drop an image, see it in your terminal. That's it. 🎨
#
# ZERO setup. Just run:
#   python3 foto.py
#   python3 foto.py mycat.jpg
#   foto mycat.jpg          ← after running install.sh
#
# Everything else is handled automatically.
# ─────────────────────────────────────────────────────────────────────────────

from __future__ import annotations

import os
import sys

# ── Make sure we are on Python 3.8+ before doing anything else ───────────────
if sys.version_info < (3, 8):
    sys.exit("❌  Python 3.8 or newer is required.  Run: python3 foto.py")


# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 – Auto-install missing dependencies (silent, first-run only)
# ─────────────────────────────────────────────────────────────────────────────
import importlib
import subprocess


def _ensure(package: str, import_name: str | None = None) -> bool:
    """
    Return True if *package* is importable; install it silently and return
    True on success; return False if installation fails.
    """
    name = import_name or package
    if importlib.util.find_spec(name) is not None:
        return True

    print(f"  📦  Installing {package} … ", end="", flush=True)
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--quiet", package],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        importlib.invalidate_caches()
        ok = importlib.util.find_spec(name) is not None
        print("✅" if ok else "❌")
        return ok
    except Exception:
        print("❌")
        return False


# Show the banner only when deps might need installing (keeps it fast normally).
_deps_banner_shown = False


def _show_banner_once() -> None:
    global _deps_banner_shown
    if not _deps_banner_shown:
        print("\n🎨  foto — setting things up (first run only) …")
        _deps_banner_shown = True


_pillow_ok = importlib.util.find_spec("PIL") is not None
_termimage_ok = importlib.util.find_spec("termimage") is not None

if not _pillow_ok or not _termimage_ok:
    _show_banner_once()

if not _pillow_ok:
    _pillow_ok = _ensure("Pillow", "PIL")

if not _termimage_ok:
    _termimage_ok = _ensure("termimage")

if _deps_banner_shown:
    print()  # blank line after install messages


# ─────────────────────────────────────────────────────────────────────────────
# Now that deps are (hopefully) present, do the real imports
# ─────────────────────────────────────────────────────────────────────────────
import argparse
import shutil
import warnings
from pathlib import Path
from typing import Optional

if _pillow_ok:
    from PIL import Image, UnidentifiedImageError  # type: ignore

if _termimage_ok:
    try:
        from termimage import image_from_file, output_image  # type: ignore
    except Exception:
        _termimage_ok = False


# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────
ASCII_CHARS = " .,:;i1tfLCG08@"
MIN_WIDTH = 10
MAX_WIDTH = 500

_TRUECOLOR_TERM_PROGRAMS = frozenset(
    {
        "iterm.app", "iterm2", "hyper", "wezterm", "vscode",
        "warp", "tabby", "terminus", "alacritty", "kitty",
        "contour", "rio", "gnome-terminal",
    }
)

# ─────────────────────────────────────────────────────────────────────────────
# Terminal helpers
# ─────────────────────────────────────────────────────────────────────────────


def terminal_width() -> int:
    env = os.environ.get("COLUMNS", "").strip()
    if env.isdigit():
        return max(MIN_WIDTH, min(int(env), MAX_WIDTH))
    return max(MIN_WIDTH, min(shutil.get_terminal_size((80, 24)).columns, MAX_WIDTH))


def supports_truecolor() -> bool:
    ct = os.environ.get("COLORTERM", "").lower()
    if ct in ("truecolor", "24bit"):
        return True
    tp = os.environ.get("TERM_PROGRAM", "").lower()
    if tp in _TRUECOLOR_TERM_PROGRAMS:
        return True
    if os.environ.get("VTE_VERSION"):
        return True
    if "256color" in os.environ.get("TERM", ""):
        try:
            r = subprocess.run(
                ["tput", "colors"], capture_output=True, text=True, timeout=2
            )
            if r.returncode == 0 and r.stdout.strip() == "16777216":
                return True
        except Exception:
            pass
    return False


# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 – Pick an image file (GUI or terminal prompt)
# ─────────────────────────────────────────────────────────────────────────────
_IMAGE_EXTS = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp",
    ".webp", ".tiff", ".tif", ".ico", ".avif",
}


def pick_file_gui() -> Optional[str]:
    """Try to open a native file-picker dialog. Returns path or None."""
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(
            title="Pick an image to view in your terminal 🎨",
            filetypes=[
                ("Images", " ".join(f"*{e}" for e in sorted(_IMAGE_EXTS))),
                ("All files", "*.*"),
            ],
        )
        root.destroy()
        return path or None
    except Exception:
        return None


def pick_file_terminal() -> Optional[str]:
    """Ask for a file path interactively in the terminal."""
    print("╔══════════════════════════════════════════╗")
    print("║  🎨  foto — terminal image viewer         ║")
    print("╚══════════════════════════════════════════╝")
    print()
    print("  Drag an image file here and press Enter,")
    print("  or type the path and press Enter.")
    print("  (Press Ctrl-C to quit.)")
    print()
    try:
        path = input("  📁  Image path: ").strip().strip("'\"")
        return path or None
    except (KeyboardInterrupt, EOFError):
        print("\n  👋  Bye!")
        sys.exit(0)


def resolve_image_path(cli_path: Optional[str]) -> Path:
    """
    Return a validated Path to an image, obtained from:
      CLI argument → GUI picker → terminal prompt.
    Loops until a valid path is given.
    """
    candidate = cli_path

    while True:
        if not candidate:
            # Try GUI first; fall back to terminal prompt
            candidate = pick_file_gui() or pick_file_terminal()

        if not candidate:
            print("  ⚠️  No file chosen. Please try again.")
            candidate = None
            continue

        p = Path(candidate.strip())

        if not p.exists():
            print(f"\n  ❌  Can't find that file: {p}")
            print("      Double-check the path and try again.\n")
            candidate = None
            continue

        if not p.is_file():
            print(f"\n  ❌  That's not a file: {p}")
            print("      Please choose an image file.\n")
            candidate = None
            continue

        if p.suffix.lower() not in _IMAGE_EXTS and not cli_path:
            print(
                f"  ⚠️  '{p.suffix}' doesn't look like an image extension, "
                "but I'll try anyway…"
            )

        return p


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 – Render the image
# ─────────────────────────────────────────────────────────────────────────────


def _open_pil(path: Path) -> "Image.Image":
    try:
        img = Image.open(path)
        img.load()
        return img
    except UnidentifiedImageError:
        _die(
            f"I can't read that file as an image: {path.name}\n"
            "      Supported: JPEG, PNG, GIF, BMP, WEBP, TIFF …\n"
            "      The file might be corrupted — try opening it in an image viewer."
        )
    except OSError as e:
        _die(
            f"Couldn't open the file: {e}\n"
            "      The file might be broken or still downloading."
        )


# ── Renderer 1: termimage ─────────────────────────────────────────────────────

def render_termimage(path: Path, width: int) -> bool:
    if not _termimage_ok:
        return False
    try:
        output_image(image_from_file(str(path)), width=width)
        return True
    except Exception as e:
        warnings.warn(f"termimage failed ({e}); trying next method.", RuntimeWarning, 2)
        return False


# ── Renderer 2: ANSI truecolor block art (▄ half-block) ──────────────────────

def render_blocks(path: Path, width: int, height: Optional[int] = None) -> bool:
    if not _pillow_ok:
        return False
    img = _open_pil(path).convert("RGB")
    target_h = height or max(1, int(width * img.height / img.width * 0.5))
    img = img.resize((width, target_h * 2), Image.LANCZOS)
    px = img.load()
    reset = "\x1b[0m"
    lines = []
    for row in range(0, target_h * 2, 2):
        parts = []
        for col in range(width):
            r1, g1, b1 = px[col, row]
            r2, g2, b2 = px[col, row + 1]
            parts.append(
                f"\x1b[38;2;{r1};{g1};{b1}m\x1b[48;2;{r2};{g2};{b2}m▄"
            )
        lines.append("".join(parts) + reset)
    print("\n".join(lines))
    return True


# ── Renderer 3: ASCII art (always works if Pillow is present) ─────────────────

def render_ascii(
    path: Path,
    width: int,
    height: Optional[int] = None,
    color: bool = False,
) -> bool:
    if not _pillow_ok:
        return False
    img = _open_pil(path)
    gray = img.convert("L")
    rows = height or max(1, int(width * gray.height / gray.width * 0.45))
    gray = gray.resize((width, rows), Image.LANCZOS)

    color_px = None
    if color:
        ci = img.convert("RGB").resize((width, rows), Image.LANCZOS)
        color_px = ci.load()

    gray_px = gray.load()
    n = len(ASCII_CHARS) - 1
    total = rows

    for row in range(total):
        if total >= 20 and row % max(1, total // 20) == 0:
            pct = int(row / total * 100)
            print(f"\r  🖼️  Rendering … {pct:3d}%", end="", flush=True, file=sys.stderr)

        parts = []
        for col in range(width):
            ch = ASCII_CHARS[int(gray_px[col, row] / 255 * n)]
            if color_px:
                r, g, b = color_px[col, row]
                ri, gi, bi = (round(c / 255 * 5) for c in (r, g, b))
                idx = 16 + 36 * ri + 6 * gi + bi
                parts.append(f"\x1b[38;5;{idx}m{ch}")
            else:
                parts.append(ch)

        reset = "\x1b[0m" if color else ""
        print("".join(parts) + reset)

    if total >= 20:
        print(f"\r  🖼️  Rendering … done!    ", file=sys.stderr)
    return True


# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 – Orchestrate everything
# ─────────────────────────────────────────────────────────────────────────────


def _die(msg: str, code: int = 1) -> None:
    print(f"\n  ❌  {msg}\n", file=sys.stderr)
    sys.exit(code)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="foto",
        description="🎨 Display any image right inside your terminal.",
        add_help=True,
    )
    p.add_argument(
        "image", nargs="?", default=None,
        help="Image file (optional — a picker opens if omitted).",
    )
    p.add_argument("--width",  "-W", type=int, default=None, metavar="COLS",
                   help="Width in columns (default: terminal width).")
    p.add_argument("--height", "-H", type=int, default=None, metavar="ROWS",
                   help="Height in rows (default: auto).")
    p.add_argument("--ascii",        action="store_true",
                   help="Force ASCII art mode.")
    p.add_argument("--trust",  "-t", action="store_true",
                   help="Assume truecolor even if not auto-detected.")
    p.add_argument("--no-color",     action="store_true",
                   help="Plain monochrome ASCII, no colour codes.")
    return p.parse_args()


def main() -> None:
    args   = parse_args()
    path   = resolve_image_path(args.image)
    width  = args.width or int(os.environ.get("FOTO_WIDTH", "0")) or terminal_width()
    height: Optional[int] = args.height or (int(os.environ.get("FOTO_HEIGHT", "0")) or None)
    color  = args.trust or supports_truecolor()

    print(f"\n  🖼️  {path.name}  ({path.stat().st_size // 1024 or 1} KB)\n")

    # ── Forced plain ASCII ───────────────────────────────────────────────────
    if args.ascii or args.no_color:
        render_ascii(path, width, height, color=not args.no_color)
        return

    # ── Auto pipeline ────────────────────────────────────────────────────────
    if color:
        if render_termimage(path, width):
            return
        if render_blocks(path, width, height):
            return

    # Colour unavailable or renderers failed → ASCII with 256-colour if possible
    if not color:
        print(
            "  ℹ️  Truecolor not detected → using ASCII art.\n"
            "     (Add --trust to force colour if your terminal supports it.)\n"
        )

    if render_ascii(path, width, height, color=color):
        return

    _die(
        "Nothing could render the image.\n"
        "      Run this to fix it:\n\n"
        "          python3 -m pip install Pillow termimage\n"
    )


if __name__ == "__main__":
    main()
